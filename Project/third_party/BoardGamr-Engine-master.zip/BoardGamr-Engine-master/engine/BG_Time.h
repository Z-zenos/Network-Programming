#ifndef BG_TIME_H
#define BG_TIME_H

#define USE_MISC_MODULE
#include "BG_Misc.h"

/*Time related methods.*/
void BG_TimeDelay(const int);
void BG_StartTime(void);
double BG_StopTime(void);
#endif // BG_TIME_H
